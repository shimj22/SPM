import { LightningElement, api, track, wire } from "lwc";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";

import momentJS from "@salesforce/resourceUrl/momentJS";
import momentJS_tz from "@salesforce/resourceUrl/momentJS_tz";
import { loadScript } from "lightning/platformResourceLoader";

//import getChartData from "@salesforce/apex/newGanttChart.getChartData";
import getGanttChartSettings from "@salesforce/apex/newGanttChart.getGanttChartSettings";
import setGanttChartSettings from "@salesforce/apex/newGanttChart.setGanttChartSettings";
import getProjects from "@salesforce/apex/newGanttChart.getProjects";
import getResources from "@salesforce/apex/newGanttChart.getResources";
import getGanttChartData from "@salesforce/apex/newGanttChart.getGanttChartData";

import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import TASK_STATUS_FIELD from '@salesforce/schema/Assignment__c.Status__c';
import PROJECT_STATUS_FIELD from '@salesforce/schema/Project__c.Status__c';
import PROJECT_TYPE_FIELD from '@salesforce/schema/Project__c.Project_Type__c';
import PROJECT_AREA_FIELD from '@salesforce/schema/Project__c.Region__c';

import USER_TIME_ZONE from '@salesforce/i18n/timeZone';

export default class GanttChart extends LightningElement {
    
    TIME_ZONE = 'Etc/UTC'; // To set the default timezone to UTC (GMT)
    DEFAULT_GANTT_VIEW = 'resource-overview'; // To set the default view of the gantt chart if the 'defaultView' property is not set from the lightning page
    DEFAULT_ROWS_PER_PAGE = 10; // The default number of Project/Resource records per page

    @api recordId;
    @api objectApiName;

    isLoading = true;

    currentView;
    isResourceOverview;
    isProjectOverview;
    isResourceRecordView;
    isProjectRecordView;
    
    //isResourceView;

    // design attributes
    @api defaultView;
    @api defaultTimelineView;

    // navigation
    startDateUTC; // sending to backend using time string
    endDateUTC; // sending to backend using time string
    formattedStartDate; // Title (Date Range)
    formattedEndDate; // Title (Date Range)
    @track dates = []; // Dates (Header)
    dateShift = 7; // determines how many days shift by when clicking the next and previous buttons

    // options
    datePickerString; // Date Navigation
    @track view = {
        // View Select
        options: [
            {
                label: "View 1 week",
                value: "1/7"
            },
            {
                label: "View 2 weeks",
                value: "1/14"
            },
            //{
            //label: "View by Week",
            //value: "7/10"
            //},
            {
                label: "View 4 weeks",
                value: "1/28"
            }
        ],
        slotSize: 1,
        slots: 1
    };


    @wire(getPicklistValues, {
        recordTypeId : '012000000000000AAA',
        fieldApiName : PROJECT_STATUS_FIELD
    })
    wiredStatusPickListValue({ data, error }){
        if(data){
            this.filterModalData.statusOptions = this.filterModalData.statusOptions.concat(data.values);
            console.log('this.filterModalData.statusOptions=='+JSON.stringify(this.filterModalData.statusOptions));
        }
        if(error){
            console.error('Error while fetching Project Status Picklist values: '+ JSON.stringify(error));
        }
    }
    
    @wire(getPicklistValues, {
        recordTypeId : '012000000000000AAA',
        fieldApiName : PROJECT_TYPE_FIELD
    })
    wiredTypePickListValue({ data, error }){
        if(data){
            this.filterModalData.typeOptions = this.filterModalData.typeOptions.concat(data.values);
            console.log('this.filterModalData.typeOptions=='+JSON.stringify(this.filterModalData.typeOptions));
        }
        if(error){
            console.error('Error while fetching Project Type Picklist values: '+ JSON.stringify(error));
        }
    }
    
    @wire(getPicklistValues, {
        recordTypeId : '012000000000000AAA',
        fieldApiName : PROJECT_AREA_FIELD
    })
    wiredAreaPickListValue({ data, error }){
        if(data){
            this.filterModalData.areaOptions = this.filterModalData.areaOptions.concat(data.values);
            console.log('this.filterModalData.areaOptions=='+JSON.stringify(this.filterModalData.areaOptions));
        }
        if(error){
            console.error('Error while fetching Project Area Picklist values: '+ JSON.stringify(error));
        }
    }
    
    

    /*** Modals ***/
    // TODO: move filter search to new component?
    @track filterModalData = {
        disabled: true,
        message: "",
        projects: [],
        resources: [],
        status: "",
        type: "",
        area: "",
        projManager: { id: "", name: "" },
        account: { id: "", name: "" },
        projectOptions: [],
        resourceOptions: [],
        statusOptions: [{ label: "--All--",
                          value: ""}] ,
        typeOptions: [{ label: "--All--",
                        value: ""}] ,
        areaOptions: [{ label: "--All--",
                        value: ""}]
    };

    _filterData = {
        projects: [],
        projectIds: [],
        resources: [],
        resourceIds: [],
        status: "",
        type: "",
        area: "",
        projManager: { id: "", name: "" },
        account: { id: "", name: "" }
    };

    @track resourceModalData = {};
    /*** /Modals ***/

    // gantt_chart_row
    startDate;
    endDate;
    //projectId;
    @track ganttRows = [];

    constructor() {
        super();
        this.template.addEventListener("click", this.closeDropdowns.bind(this));
    }

    connectedCallback() {
        Promise.all([
            loadScript(this, momentJS),
            loadScript(this, momentJS_tz)
        ]).then(() => {
            this.setGanttView();
            switch (this.defaultTimelineView) {
                case "View 1 week":
                    this.setTimelineView("1/7");
                    break;
                case "View 2 weeks":
                    this.setTimelineView("1/14");
                    break;
                case "View 4 weeks":
                    this.setTimelineView("1/28");
                    break;
                default:
                    this.setTimelineView("1/14");
            }

            console.log('TIME_ZONE=='+this.TIME_ZONE);
            moment.tz.setDefault(this.TIME_ZONE);
            moment.locale('en_GB');
            
            console.log('moment() after setting tz=='+moment().toString());
            
            //this.setStartDate(new Date());
            this.setStartDate(moment());

            getGanttChartSettings()
                .then((data) => {
                    console.log("custom settings data=="+ JSON.stringify(data));
                    this._filterData = {
                        projects: (data.filterProjects)? JSON.parse(data.filterProjects) : [],
                        resources: (data.filterProjects)? JSON.parse(data.filterResources) : [],
                        status: (data.filterStatus)? data.filterStatus : "",
                        type: (data.filterType)? data.filterType : "",
                        area: (data.filterArea)? data.filterArea : "",
                        projManager: (data.filterManager)? JSON.parse(data.filterManager) : { id: "", name: "" },
                        account: (data.filterAccounts)? JSON.parse(data.filterAccounts) : { id: "", name: "" }
                    };

                    this._filterData.projectIds = this._filterData.projects.map((project) => {
                        return project.id;
                    });

                    this._filterData.resourceIds = this._filterData.resources.map((resource) => {
                        return resource.id;
                    });

                    console.log("this._filterData=="+ JSON.stringify(this._filterData));

                    this.setFilterMessage();
                    this.handleRefresh();
                })
                .catch((error) => {
                    console.error(JSON.stringify(error));
                    // this.handleRefresh();
                    this.dispatchEvent(
                        new ShowToastEvent({
                            message: error.body.message,
                            variant: "error"
                        })
                    );
                });
        });
    }

    // catch blur on allocation menus
    closeDropdowns() {
        Array.from(this.template.querySelectorAll(".lwc-row-component")).forEach((row) => {
            row.closeAllocationMenu();
        });
    }

    // To set the gantt view type
    setGanttView() {
        this.isResourceOverview = false;
        this.isProjectOverview = false;
        this.isResourceRecordView = false;
        this.isProjectRecordView = false;
        //this.currentView = '';
        
        console.log('this.defaultView==',this.defaultView);

        if(!this.currentView) {
            if(this.defaultView == "Resource")
                this.currentView = "resource-overview";
            else if(this.defaultView == "Project")
                this.currentView = "project-overview";
            else
                this.currentView = this.DEFAULT_GANTT_VIEW;
        }

        if(typeof this.objectApiName !== "undefined" && this.objectApiName.endsWith("Project__c")) {
            this.currentView = 'project-record';
        }
        else if(typeof this.objectApiName !== "undefined" && this.objectApiName.endsWith("Resource__c")) {
            this.currentView = 'resource-record';
        }

        switch(this.currentView) {
            case "project-overview":
                this.isProjectOverview = true;
                break;
            case "resource-overview":
                this.isResourceOverview = true;
                break;
            case "project-record":
                this.isProjectRecordView = true;
                break;
            case "resource-record":
                this.isResourceRecordView = true;
        }
    }

    toggleGanttView() {
        if(this.currentView === "project-overview")
            this.currentView = "resource-overview";
        else if(this.currentView === "resource-overview")
            this.currentView = "project-overview";
        this.setGanttView();
        this.setFilterMessage();
        this.clearPagination();
        this.handleRefresh();
    }


    /*** Navigation ***/
    setStartDate(_startDate) {
        console.log('_startDate=='+_startDate);
        //if (_startDate instanceof Date && !isNaN(_startDate)) {
        if (!isNaN(_startDate)) {
            _startDate.startOf('day');
            console.log('_startDate = ' + _startDate);
            console.log('_startDate string = ' + _startDate.toString());
            console.log('typeof _startDate=='+ typeof _startDate);
            //_startDate.setHours(0, 0, 0, 0);

            //_startDate = new Date(Date.UTC(_startDate.getFullYear(), _startDate.getMonth(), _startDate.getDate(), 0, 0, 0));
            console.log("R3>>> _startDate = " + _startDate);

            //this.datePickerString = _startDate.toISOString();
            this.datePickerString = _startDate.format();

            //this.startDate = moment(_startDate).day(1).toDate();
            this.startDate = _startDate.subtract(1,'days').day(1).toDate();
            
            this.startDateUTC = _startDate + "";
            //this.startDateUTC = moment(this.startDate).utc().valueOf() - moment(this.startDate).utcOffset() * 60 * 1000 + "";
            
            //this.formattedStartDate = this.startDate.toLocaleDateString();
            this.formattedStartDate = _startDate.format('DD/MM/YYYY');
            console.log('formattedStartDate=='+this.formattedStartDate);

            console.log("R3>>> startDate = " + this.startDate);
            console.log("R3>>> startDateUTC = " + this.startDateUTC.toString());

            this.setDateHeaders();
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    message: "Invalid Date",
                    variant: "error"
                })
            );
        }
    }

    setDateHeaders() {
        let _endDate = moment(this.startDate).add(this.view.slots * this.view.slotSize - 1, "days");
        this.endDate = _endDate.toDate();
        this.endDateUTC = _endDate + "";
        //this.endDateUTC = moment(this.endDate).utc().valueOf() + ""; //- moment(this.endDate).utcOffset() * 60 * 1000 + "";
        console.log('endDateUTC=='+this.endDateUTC.toString());
        //this.formattedEndDate = this.endDate.toLocaleDateString();
        this.formattedEndDate = _endDate.format('DD/MM/YYYY');
        console.log('formattedEndDate=='+this.formattedEndDate);

        const dayNames = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
        
        //let today = new Date();
        //today.setHours(0, 0, 0, 0);
        //today = today.getTime();
        let today = moment().startOf('day').toDate();

        let dates = {};

        let date = moment(this.startDate);

        // for (let date = moment(this.startDate); date <= moment(this.endDate); date.add(this.view.slotSize, "days")) {
        while(date <= moment(this.endDate)) {
            let index = date.format("YYYYMM");
            if (!dates[index]) {
                dates[index] = {
                    dayName: "",
                    name: date.format("MMMM"),
                    days: []
                };
            }

            let day = {
                class: "slds-col slds-p-vertical_x-small slds-m-top_x-small lwc-timeline_day",
                //label: date.format("M/D"),
                label: date.format("DD/MM"),
                start: date.toDate()
            };

            if (this.view.slotSize > 1) {
                let end = moment(date).add(this.view.slotSize - 1, "days");
                day.end = end.toDate();
            } else {
                day.end = date.toDate();
                day.dayName = date.format("ddd");
                if(date.day() === 0) {
                    day.class += " lwc-is-week-end";
                    day.class += " lwc-is-disabled";
                } else if(date.day() === 6) {
                    day.class += " lwc-is-disabled";
                }
            }

            if (today >= day.start && today <= day.end) {
                day.class += " lwc-is-today";
            }

            dates[index].days.push(day);
            dates[index].style = "width: calc(" + dates[index].days.length + "/" + this.view.slots + "*100%)";

            console.log('this.view.slotSize=='+this.view.slotSize);
            console.log('date before incr==', date.format());
            if(this.view.slotSize < 1)
                date.add(1, "days");
            else
                date.add(this.view.slotSize, "days");
            console.log('date after incr==', date.format());
        }
        console.log('loop is complete');

        // reorder index
        this.dates = Object.values(dates);

        Array.from(this.template.querySelectorAll("c-gantt_chart_row")).forEach((row) => {
            row.refreshDates(this.startDate, this.endDate, this.view.slotSize);
        });
    }

    navigateToToday() {
        //this.setStartDate(new Date());
        this.setStartDate(moment());
        this.handleRefresh();
    }

    navigateToPrevious() {
        let _startDate = new Date(this.startDate);
        _startDate.setDate(_startDate.getDate() - this.dateShift);

        let _start = moment(this.startDate).subtract(this.dateShift, "days");
        this.setStartDate(_start);

        //this.setStartDate(_startDate);
        this.handleRefresh();
    }

    navigateToNext() {
        let _startDate = new Date(this.startDate);
        _startDate.setDate(_startDate.getDate() + this.dateShift);

        let _start = moment(this.startDate).add(this.dateShift, "days");
        this.setStartDate(_start);

        //this.setStartDate(_startDate);
        this.handleRefresh();
    }

    navigateToDay(event) {
        //this.setStartDate(new Date(event.target.value + "T00:00:00"));
        this.setStartDate(moment(event.target.value + "T00:00:00"));
        this.handleRefresh();
    }

    setTimelineView(value) {
        let values = value.split("/");
        console.log('timelineValues==', values);
        this.view.value = value;
        // this.view.slotSize = parseInt(values[0], 10);
        this.view.slotSize = parseFloat(values[0]);
        this.view.slots = parseInt(values[1], 10);
        console.log('this.view.slotSize==' + this.view.slotSize);
        console.log('this.view.slots==' + this.view.slots);
    }

    handleViewChange(event) {
        this.setTimelineView(event.target.value);
        this.setDateHeaders();
        this.handleRefresh();
    }
    /*** /Navigation ***/


    /*** Pagination for gantt rows ***/

    @track paginationData = {
        pageNumber: 0,
        rowsPerPage: this.DEFAULT_ROWS_PER_PAGE,
        isNextDisabled: true,
        isPreviousDisabled: true,
        rangeStart: 0,
        rangeEnd: 0,
        totalRows: 0,
        totalPages: 0,
        paginationText: ""
    };
    
    goToNextPage(event) {
        if(this.paginationData.pageNumber < this.paginationData.totalPages) {
            this.paginationData.pageNumber++;
            this.handleRefresh();
        }
    }
    goToPreviousPage(event) {
        if(this.paginationData.pageNumber > 0) {
            this.paginationData.pageNumber--;
            this.handleRefresh();
        }
    }

    setPagination(totalRows) {
        if(totalRows != null)
            this.paginationData.totalRows = totalRows;
        else
            totalRows = this.paginationData.totalRows;
        
        let rowsPerPage = this.paginationData.rowsPerPage;
        this.paginationData.totalPages = Math.ceil(totalRows / rowsPerPage) - 1;
        let pageNumber = this.paginationData.pageNumber;
        this.paginationData.rangeStart = (pageNumber * rowsPerPage) + 1;
        this.paginationData.rangeEnd = Math.min(totalRows, (pageNumber + 1) * rowsPerPage);
        this.paginationData.paginationText = "Showing " +this.paginationData.rangeStart+ "-" +this.paginationData.rangeEnd+ " of " + totalRows;
    
        this.paginationData.isNextDisabled = true;
        this.paginationData.isPreviousDisabled = true;
        if(this.paginationData.pageNumber > 0)
            this.paginationData.isPreviousDisabled = false;
        if(this.paginationData.pageNumber < this.paginationData.totalPages)
            this.paginationData.isNextDisabled = false;
    }

    clearPagination() {
        this.paginationData.pageNumber = 0;
        // this.setPagination();
    }
    /*** /Pagination for gantt rows ***/


    /*** Filter Modal ***/
    stopProp(event) {
        event.stopPropagation();
    }

    clearFocus() {
        this.filterModalData.focus = null;
    }

    openFilterModal() {
        this.filterModalData.projects = Object.assign([], this._filterData.projects);
        this.filterModalData.resources = Object.assign([], this._filterData.resources);
        this.filterModalData.status = this._filterData.status;
        this.filterModalData.type = this._filterData.type;
        this.filterModalData.area = this._filterData.area;
        this.filterModalData.projManager = Object.assign({}, this._filterData.projManager);
        this.filterModalData.account = Object.assign({}, this._filterData.account);
        console.log("this.filterModalData== " + JSON.stringify(this.filterModalData));
        this.setFilterModalDataDisable();
        this.template.querySelector(".filter-modal").show();
    }

    filterResources(event) {
        this.hideDropdowns();
        let text = event.target.value;

        getResources().then((resources) => {
            console.log("resources from apex== " + JSON.stringify(resources));
            console.log("this.filterModalData.resources== " + JSON.stringify(this.filterModalData.resources));

            // only show resource not selected
            this.filterModalData.resourceOptions = resources.filter((resource) => {
                return (
                    resource.name &&
                    resource.name.toLowerCase().includes(text.toLowerCase()) &&
                    !this.filterModalData.resources.filter((r) => {
                        return r.id === resource.id;
                    }).length
                );
            });
            console.log("this.filterModalData.resourceOptions = " + JSON.stringify(this.filterModalData.resourceOptions));
            this.filterModalData.focus = "resources";
        });
    }

    filterProjects(event) {
        this.hideDropdowns();
        let text = event.target.value;

        getProjects().then((projects) => {
            // only show projects not selected
            this.filterModalData.projectOptions = projects.filter((project) => {
                return (
                    project.name &&
                    project.name.toLowerCase().includes(text.toLowerCase()) &&
                    !this.filterModalData.projects.filter((p) => {
                        return p.id === project.id;
                    }).length
                );
            });
            this.filterModalData.focus = "projects";
        });
    }

    addResourceFilter(event) {
        this.filterModalData.resources.push(Object.assign({}, event.currentTarget.dataset));
        this.filterModalData.focus = null;
        this.setFilterModalDataDisable();
    }
    removeResourceFilter(event) {
        this.filterModalData.resources.splice(event.currentTarget.dataset.index, 1);
        this.setFilterModalDataDisable();
    }

    addProjectFilter(event) {
        this.filterModalData.projects.push(Object.assign({}, event.currentTarget.dataset));
        this.filterModalData.focus = null;
        this.setFilterModalDataDisable();
    }
    removeProjectFilter(event) {
        this.filterModalData.projects.splice(event.currentTarget.dataset.index, 1);
        this.setFilterModalDataDisable();
    }

    setStatusFilter(event) {
        this.filterModalData.status = event.currentTarget.value;
        this.setFilterModalDataDisable();
    }
    setTypeFilter(event) {
        this.filterModalData.type = event.currentTarget.value;
        this.setFilterModalDataDisable();
    }
    setAreaFilter(event) {
        this.filterModalData.area = event.currentTarget.value;
        this.setFilterModalDataDisable();
    }

    setProjectManagerFilter(event) {
        console.log('event=='+JSON.stringify(event));
        // this.filterModalData.projManager = event.detail.id;
        this.filterModalData.projManager = {
            id: event.detail.id,
            name: event.detail.name
        };
        this.setFilterModalDataDisable();
    }
    removeProjectManagerFilter(event) {
        console.log('event=='+JSON.stringify(event));
        // this.filterModalData.projManager = "";
        this.filterModalData.projManager = { id: "", name: "" };
        this.setFilterModalDataDisable();
    }

    setAccountFilter(event) {
        console.log('event=='+JSON.stringify(event));
        // this.filterModalData.account = event.detail.id;
        this.filterModalData.account = {
            id: event.detail.id,
            name: event.detail.name
        };
        this.setFilterModalDataDisable();
    }
    removeAccountFilter(event) {
        console.log('event=='+JSON.stringify(event));
        this.filterModalData.account = { id: "", name: "" };
        this.setFilterModalDataDisable();
    }

    clearFilters() {
        this.filterModalData.projects = [];
        this.filterModalData.projectSearch = "";
        this.filterModalData.resources = [];
        this.filterModalData.resourceSearch = "";
        this.filterModalData.status = "";
        this.filterModalData.type = "";
        this.filterModalData.area = "";
        // this.filterModalData.projManager = "";
        this.filterModalData.projManager = { id: "", name: "" };
        this.filterModalData.account = { id: "", name: "" };
        this.filterModalData.disabled = true;

        Array.from(this.template.querySelectorAll("c-custom-lookup")).forEach((lookupFilter) => {
            lookupFilter.removeSelection();
        });
    }

    setFilterModalDataDisable() {
        this.filterModalData.disabled = true;

        if (this.filterModalData.projects.length > 0 || this.filterModalData.resources.length > 0 || 
            this.filterModalData.status !== "" || this.filterModalData.type !== "" || this.filterModalData.area !== "" || 
            this.filterModalData.projManager.id !== "" || this.filterModalData.account.id !== "") 
        {
            this.filterModalData.disabled = false;
        }
    }

    hideDropdowns() {
        // prevent menu from closing if focused
        if (this.filterModalData.focus) {
            return;
        }
        this.filterModalData.projectOptions = [];
        this.filterModalData.resourceOptions = [];
    }

    applyFilters() {
        this._filterData = {
            projects: Object.assign([], this.filterModalData.projects),
            resources: Object.assign([], this.filterModalData.resources),
            status: this.filterModalData.status,
            type: this.filterModalData.type,
            area: this.filterModalData.area,
            projManager: Object.assign({}, this.filterModalData.projManager),
            account: Object.assign({}, this.filterModalData.account)
        };

        this._filterData.projectIds = this._filterData.projects.map((project) => {
            return project.id;
        });

        this._filterData.resourceIds = this._filterData.resources.map((resource) => {
            return resource.id;
        });

        this.setFilterMessage();

        let self = this;
        setGanttChartSettings({
            filterResources: JSON.stringify(self._filterData.resources),
            filterProjects: JSON.stringify(self._filterData.projects),
            filterStatus: self._filterData.status,
            filterType: self._filterData.type,
            filterArea: self._filterData.area,
            filterManager: JSON.stringify(self._filterData.projManager),
            filterAccounts: JSON.stringify(self._filterData.account)
        }).then(() => {
            console.log('Filters saved to custom settings');
        }).catch((error) => {
            console.error(JSON.stringify(error));
            /* this.dispatchEvent(
                new ShowToastEvent({
                    message: error.body.message,
                    variant: "error"
                })
            ); */
        });
        this.clearPagination();
        this.handleRefresh();
        this.template.querySelector(".filter-modal").hide();
    }

    setFilterMessage() {
        let filters = [];
        if (this._filterData.resources.length && this.isResourceOverview) {
            filters.push("Resources");
        }
        if (this._filterData.projects.length) {
            filters.push("Projects");
        }
        if (this._filterData.status) {
            filters.push("Status");
        }
        if (this._filterData.type) {
            filters.push("Type");
        }
        if (this._filterData.area) {
            filters.push("Region");
        }
        if (this._filterData.projManager.id) {
            filters.push("Project Manager");
        }
        if (this._filterData.account.id) {
            filters.push("Account");
        }

        if (filters.length) {
            this._filterData.message = "Filtered By " + filters.join(", ");
        }
    }
    /*** /Filter Modal ***/


    handleRefresh() {
        // refreshApex(this.wiredData);
        this.isLoading = true;
        let self = this;

        getGanttChartData({
            recordId: (self.recordId)? self.recordId : "",
            viewMode: self.currentView,
            startTime: self.startDateUTC,
            endTime: self.endDateUTC,
            slotSize: self.view.slotSize,
            pageNumber: self.paginationData.pageNumber,
            recordsPerPage: self.paginationData.rowsPerPage,
            filterResources: self._filterData.resourceIds,
            filterProjects: self._filterData.projectIds,
            filterStatus: self._filterData.status,
            filterType: self._filterData.type,
            filterArea: self._filterData.area,
            filterProjManager: self._filterData.projManager.id,
            filterAccount: self._filterData.account.id
        })
            .then((data) => {
                //self.projectId = data.projectId;
                
                // empty old data present in the variable
                if(self.ganttRows.length) {
                    self.ganttRows.splice(0, self.ganttRows.length);
                }


                self.ganttRows = JSON.parse(JSON.stringify(data.ganttRows));
                console.log("data.totalRows==",data.totalRows);
                self.setPagination(data.totalRows);
                self.isLoading = false;

                // Trying to fix disordered pagination
                if(this.delayTimeout) {
                    // eslint-disable-next-line @lwc/lwc/no-async-operation
                    clearTimeout(this.delayTimeout);
                }
                // eslint-disable-next-line @lwc/lwc/no-async-operation
                this.delayTimeout = setTimeout(() => {
                    
                }, 0);
                // fix ends

            })
            .catch((error) => {
                console.error(JSON.stringify(error));
                this.dispatchEvent(
                    new ShowToastEvent({
                        message: error.body.message,
                        variant: "error"
                    })
                );
                this.isLoading = false;
            });
    }


}